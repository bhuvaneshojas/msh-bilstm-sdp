# MSH-BiLSTM: Multi-Scale Hierarchical BiLSTM for Software Defect Prediction

A novel software defect prediction framework using dual-scale Bidirectional LSTM
with combined self-attention and cross-attention, replacing the prior
Transformer + ensemble stack with a single, coherent architecture.

## Architecture

```
Input X_T (version sequence, T x K)
  |
  +-- Fine-grained BiLSTM  (every step)       -> H_fine   (T   x 2H)
  +-- Coarse-grained BiLSTM (pooled windows)  -> H_coarse (T/K x 2H)
  |
  Step 1: Self-attention (each stream refines itself)
  Step 2: Cross-attention (streams exchange information, parallel)
  |
  Pool + project -> v_final (2H)
  |
  Single dense head -> P(defect | x)
```

## Setup

```bash
pip install -r requirements.txt
```

## Datasets

Download NASA PROMISE datasets (.arff format) from:
https://promise.site.uottawa.ca/SERepository/

Place in `data/raw/`:
```
data/raw/cm1.arff
data/raw/jm1.arff
data/raw/kc1.arff
data/raw/pc1.arff
data/raw/mc2.arff
```

## Run

```bash
# Real data
python run_experiment.py --dataset KC1 --data_path data/raw/kc1.arff

# Smoke test (no real data needed)
python run_experiment.py --dataset KC1 --synthetic

# GPU
python run_experiment.py --dataset JM1 --data_path data/raw/jm1.arff --device cuda
```

## Key hyperparameters

| Parameter | Default | Description |
|---|---|---|
| `--hidden_dim` | 64 | BiLSTM hidden units per direction |
| `--coarse_k` | 3 | Coarse window size K |
| `--seq_len` | 5 | Sequence length T |
| `--afs_alpha` | 0.6 | MI vs SHAP balance in AFS-SHAP |
| `--dropout` | 0.30 | Dropout rate |
| `--lr` | 3e-4 | Learning rate |
| `--share_self_attn` | True | Share self-attention weights between streams |

## Project structure

```
msh_bilstm/
  data/
    loader.py        # PROMISE .arff loader
    preprocessing.py # Imputation, normalization, AFS-SHAP, DC-GAN
    sequencer.py     # Tabular -> version sequence builder
  models/
    msh_bilstm.py    # Core model: AdditiveAttention, DualBiLSTMEncoder, MSHBiLSTM
  training/
    trainer.py       # Training loop, early stopping, Youden threshold
  evaluation/
    metrics.py       # F1/AUC/MCC, fold aggregation, Wilcoxon, Cohen's d
  run_experiment.py  # Main entry point
  requirements.txt
```

## Honest note

This is a research prototype. No published benchmark results exist yet.
The architecture is internally consistent and implements the design described
in the accompanying paper draft. Real results require running on actual
PROMISE datasets with this code.
