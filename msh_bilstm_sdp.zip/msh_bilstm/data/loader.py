"""
data/loader.py
--------------
Loads NASA PROMISE datasets from .arff files.
Download from: https://promise.site.uottawa.ca/SERepository/
Supported: CM1, JM1, KC1, PC1, MC2

Usage:
    from data.loader import load_promise_dataset
    X, y, feature_names = load_promise_dataset("data/raw/cm1.arff")
"""

import numpy as np
import os
from typing import Tuple, List


def load_promise_dataset(path: str) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    """
    Parse a PROMISE .arff file and return feature matrix, labels, feature names.
    Label column is the last attribute named 'defects' or 'Defective'.
    Returns X (n, d), y (n,) as 0/1, feature_names (d,)
    """
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Dataset not found at {path}.\n"
            f"Download from https://promise.site.uottawa.ca/SERepository/\n"
            f"and place .arff files in data/raw/"
        )

    rows, attrs = [], []
    in_data = False

    with open(path, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("%"):
                continue
            low = line.lower()
            if low.startswith("@attribute"):
                parts = line.split()
                attrs.append(parts[1].strip("'\""))
            elif low.startswith("@data"):
                in_data = True
            elif in_data and line:
                rows.append(line.split(","))

    data = np.array(rows)

    # label is the last column; map yes/true/1 -> 1, else 0
    raw_labels = data[:, -1].tolist()
    y = np.array([
        1 if str(v).strip().lower() in ("yes", "true", "1", "y", "defective")
        else 0
        for v in raw_labels
    ], dtype=np.int64)

    # features: all columns except last, cast to float
    # drop columns that are entirely non-numeric (e.g. module name)
    X_raw = data[:, :-1]
    feature_names = attrs[:-1]
    keep = []
    for j in range(X_raw.shape[1]):
        try:
            X_raw[:, j].astype(float)
            keep.append(j)
        except ValueError:
            pass

    X = X_raw[:, keep].astype(float)
    feature_names = [feature_names[j] for j in keep]

    print(f"Loaded {path}: {X.shape[0]} modules, {X.shape[1]} features, "
          f"{y.sum()} defective ({100*y.mean():.1f}%)")
    return X, y, feature_names


def make_synthetic_promise(n: int = 500, d: int = 21,
                           defect_rate: float = 0.12,
                           seed: int = 42) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    """
    Synthetic fallback for smoke-testing without real data.
    Mimics the statistical properties of KC1 (n=2109, d=21, 15.5% defective).
    NOT a substitute for real evaluation.
    """
    rng = np.random.default_rng(seed)
    feature_names = [
        "wmc", "dit", "noc", "cbo", "rfc", "lcom", "ca", "ce", "npm",
        "lcom3", "loc", "dam", "moa", "mfa", "cam", "ic", "cbm",
        "amc", "max_cc", "avg_cc", "bug"
    ][:d]

    # Non-defective modules: lower complexity
    n_neg = int(n * (1 - defect_rate))
    n_pos = n - n_neg

    X_neg = rng.lognormal(mean=1.5, sigma=0.8, size=(n_neg, d))
    X_pos = rng.lognormal(mean=2.2, sigma=1.1, size=(n_pos, d))

    X = np.vstack([X_neg, X_pos])
    y = np.array([0] * n_neg + [1] * n_pos, dtype=np.int64)
    shuffle = rng.permutation(n)
    return X[shuffle], y[shuffle], feature_names
