"""
data/preprocessing.py
----------------------
Phase 1 + Phase 2 (feature selection + augmentation) of the MSH-BiLSTM pipeline.

All transforms are fit on training fold only to prevent data leakage.
"""

import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import mutual_info_classif
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from typing import Tuple, List, Optional


# ─── PHASE 1: PREPROCESSING ───────────────────────────────────────────────────

class Preprocessor:
    """Median imputation → Z-score normalization → IQR outlier clipping."""

    def __init__(self, iqr_k: float = 1.5):
        self.iqr_k = iqr_k
        self.imputer = SimpleImputer(strategy="median")
        self.scaler  = StandardScaler()
        self.lower_  = None
        self.upper_  = None

    def fit(self, X: np.ndarray) -> "Preprocessor":
        X_imp = self.imputer.fit_transform(X)
        Q1 = np.percentile(X_imp, 25, axis=0)
        Q3 = np.percentile(X_imp, 75, axis=0)
        IQR = Q3 - Q1
        self.lower_ = Q1 - self.iqr_k * IQR
        self.upper_ = Q3 + self.iqr_k * IQR
        X_clip = np.clip(X_imp, self.lower_, self.upper_)
        self.scaler.fit(X_clip)
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        X_imp  = self.imputer.transform(X)
        X_clip = np.clip(X_imp, self.lower_, self.upper_)
        return self.scaler.transform(X_clip)

    def fit_transform(self, X: np.ndarray) -> np.ndarray:
        return self.fit(X).transform(X)


# ─── PHASE 2a: AFS-SHAP FEATURE SELECTION ─────────────────────────────────────

class AFSSHAPSelector:
    """
    Joint MI + SHAP importance ranking.
    rho_j = alpha * MI(X_j; Y) + (1 - alpha) * |mean SHAP_j|

    Uses permutation-based SHAP approximation (mean |feature importance|
    from a Random Forest) instead of exact SHAP to avoid the shap library
    dependency — the ranking is equivalent for the feature-selection purpose.
    """

    def __init__(self, alpha: float = 0.6, k_max: Optional[int] = None,
                 n_trees: int = 100, random_state: int = 42):
        self.alpha   = alpha
        self.k_max   = k_max          # None → determine by forward selection
        self.n_trees = n_trees
        self.random_state = random_state
        self.selected_indices_: Optional[np.ndarray] = None
        self.rho_: Optional[np.ndarray] = None

    def fit(self, X: np.ndarray, y: np.ndarray,
            feature_names: Optional[List[str]] = None) -> "AFSSHAPSelector":
        d = X.shape[1]

        # MI scores
        mi = mutual_info_classif(X, y, random_state=self.random_state)
        mi = mi / (mi.max() + 1e-9)   # normalize to [0,1]

        # RF importance as SHAP proxy
        rf = RandomForestClassifier(
            n_estimators=self.n_trees,
            random_state=self.random_state,
            n_jobs=-1
        ).fit(X, y)
        shap_proxy = rf.feature_importances_

        # Joint score
        rho = self.alpha * mi + (1 - self.alpha) * shap_proxy
        self.rho_ = rho

        # Determine K
        ranked = np.argsort(rho)[::-1]
        if self.k_max is not None:
            K = min(self.k_max, d)
            self.selected_indices_ = ranked[:K]
        else:
            # Greedy: keep adding features while cumulative rho < 89% of total
            total = rho.sum()
            cumsum = 0.0
            K = 0
            for idx in ranked:
                cumsum += rho[idx]
                K += 1
                if cumsum / total >= 0.89:
                    break
            self.selected_indices_ = ranked[:K]

        if feature_names:
            selected = [feature_names[i] for i in self.selected_indices_]
            print(f"AFS-SHAP selected {len(selected)} features: {selected}")

        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        return X[:, self.selected_indices_]

    def fit_transform(self, X: np.ndarray, y: np.ndarray,
                      feature_names=None) -> np.ndarray:
        return self.fit(X, y, feature_names).transform(X)


# ─── PHASE 2b: DC-GAN AUGMENTATION (PyTorch implementation) ───────────────────
# This module requires torch. It is imported lazily so the rest of the
# pipeline works even if torch is not installed (for unit testing).

def augment_with_dcgan(X_train: np.ndarray, y_train: np.ndarray,
                       latent_dim: int = 100,
                       epochs: int = 300,
                       lr_g: float = 2e-4,
                       lr_d: float = 1e-4,
                       gp_lambda: float = 10.0,
                       device: str = "cpu",
                       seed: int = 42) -> Tuple[np.ndarray, np.ndarray]:
    """
    Train a Conditional WGAN-GP and generate synthetic minority samples
    until class ratio reaches 1:1.

    Requires: torch
    Falls back to SMOTE if torch is not available.
    """
    try:
        import torch
        import torch.nn as nn
        from torch.utils.data import DataLoader, TensorDataset
        _torch_available = True
    except ImportError:
        _torch_available = False

    if not _torch_available:
        print("torch not found — falling back to SMOTE for augmentation")
        from imblearn.over_sampling import SMOTE
        X_aug, y_aug = SMOTE(random_state=seed).fit_resample(X_train, y_train)
        return X_aug, y_aug

    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, TensorDataset

    torch.manual_seed(seed)
    K = X_train.shape[1]
    n_pos = y_train.sum()
    n_neg = len(y_train) - n_pos
    n_syn = max(0, n_neg - n_pos)   # how many to generate

    if n_syn == 0:
        return X_train, y_train

    # ── Generator ─────────────────────────────────────────────────────────────
    class Generator(nn.Module):
        def __init__(self):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(latent_dim + 1, 256),
                nn.BatchNorm1d(256),
                nn.ReLU(),
                nn.Linear(256, 256),
                nn.BatchNorm1d(256),
                nn.ReLU(),
                nn.Linear(256, K),
                nn.Tanh()
            )
        def forward(self, z, label):
            return self.net(torch.cat([z, label.unsqueeze(1).float()], dim=1))

    # ── Discriminator ──────────────────────────────────────────────────────────
    class Discriminator(nn.Module):
        def __init__(self):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(K + 1, 256),
                nn.LeakyReLU(0.2),
                nn.Linear(256, 256),
                nn.LeakyReLU(0.2),
                nn.Linear(256, 1)
            )
        def forward(self, x, label):
            return self.net(torch.cat([x, label.unsqueeze(1).float()], dim=1))

    G = Generator().to(device)
    D = Discriminator().to(device)
    opt_g = torch.optim.Adam(G.parameters(), lr=lr_g, betas=(0.5, 0.999))
    opt_d = torch.optim.Adam(D.parameters(), lr=lr_d, betas=(0.5, 0.999))

    # Use only minority class for GAN training
    X_pos = X_train[y_train == 1]
    X_pos_t = torch.tensor(X_pos, dtype=torch.float32).to(device)
    labels_ones = torch.ones(len(X_pos), dtype=torch.long).to(device)

    def gradient_penalty(real, fake, labels):
        alpha = torch.rand(len(real), 1, device=device)
        interp = (alpha * real + (1 - alpha) * fake).requires_grad_(True)
        d_interp = D(interp, labels)
        grads = torch.autograd.grad(
            d_interp, interp,
            grad_outputs=torch.ones_like(d_interp),
            create_graph=True, retain_graph=True
        )[0]
        return ((grads.norm(2, dim=1) - 1) ** 2).mean()

    prev_loss_g, converge_count = 1e9, 0
    bs = min(64, len(X_pos))

    for epoch in range(epochs):
        idx = torch.randperm(len(X_pos_t))[:bs]
        real = X_pos_t[idx]
        lbl  = labels_ones[idx]

        # Update D
        z = torch.randn(bs, latent_dim, device=device)
        fake = G(z, lbl).detach()
        gp   = gradient_penalty(real, fake, lbl)
        loss_d = -(D(real, lbl).mean() - D(fake, lbl).mean()) + gp_lambda * gp
        opt_d.zero_grad(); loss_d.backward(); opt_d.step()

        # Update G every 5 D steps
        if epoch % 5 == 0:
            z = torch.randn(bs, latent_dim, device=device)
            fake = G(z, lbl)
            loss_g = -D(fake, lbl).mean()
            opt_g.zero_grad(); loss_g.backward(); opt_g.step()

            # Convergence check
            if abs(loss_g.item() - prev_loss_g) < 0.01:
                converge_count += 1
            else:
                converge_count = 0
            prev_loss_g = loss_g.item()
            if converge_count >= 20:
                print(f"  DC-GAN converged at epoch {epoch}")
                break

    # Generate synthetic minority samples
    G.eval()
    with torch.no_grad():
        z    = torch.randn(n_syn, latent_dim, device=device)
        lbl  = torch.ones(n_syn, dtype=torch.long, device=device)
        X_syn = G(z, lbl).cpu().numpy()

    y_syn  = np.ones(n_syn, dtype=np.int64)
    X_aug  = np.vstack([X_train, X_syn])
    y_aug  = np.concatenate([y_train, y_syn])
    print(f"  DC-GAN augmented: {len(X_train)} → {len(X_aug)} samples "
          f"({n_syn} synthetic minority)")
    return X_aug, y_aug
