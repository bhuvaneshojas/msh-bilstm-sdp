"""
data/sequencer.py
------------------
Converts flat tabular module features into padded version sequences
for the dual BiLSTM encoder.

The PROMISE datasets are snapshot-based (one row per module), not
time-series. We construct pseudo-sequences using a sliding window
over modules sorted by a proxy for 'version order':
    - If a version/release column exists, use it.
    - Otherwise sort by LOC (larger = more evolved) as a proxy.
    - For single-module inference, replicate the feature vector T times
      with mild Gaussian jitter to simulate historical steps.
"""

import numpy as np
from typing import Optional, Tuple


class SequenceBuilder:
    """
    Builds (n, T, K) sequence tensors from (n, K) tabular features.

    Strategy for snapshot datasets:
        - Sort modules by LOC (or a specified sort_col index) to get
          a plausible complexity-evolution ordering.
        - Use a sliding window of size T to create each module's sequence:
          window [i-T+1 : i+1] centered on module i.
        - Pad with zeros at the boundaries.

    This is an approximation. Real version-sequence data would be
    better but is not available in PROMISE snapshot datasets.
    """

    def __init__(self, T: int = 5, sort_col: Optional[int] = None,
                 jitter_sigma: float = 0.05, seed: int = 42):
        """
        T          : sequence length (number of pseudo-historical steps)
        sort_col   : column index to sort by (default: last column = LOC-like)
        jitter_sigma: std of Gaussian noise added to historical steps to
                      simulate metric variation across versions
        """
        self.T = T
        self.sort_col = sort_col
        self.jitter_sigma = jitter_sigma
        self.rng = np.random.default_rng(seed)

    def build(self, X: np.ndarray) -> np.ndarray:
        """
        X : (n, K) normalized tabular features
        Returns sequences : (n, T, K)
        """
        n, K = X.shape
        T = self.T

        # Sort by proxy column to impose version order
        sort_col = self.sort_col if self.sort_col is not None else -1
        order = np.argsort(X[:, sort_col])
        X_sorted = X[order]     # sorted modules
        reverse_order = np.argsort(order)  # to restore original order later

        # Build padded sliding window sequences
        seqs = np.zeros((n, T, K), dtype=np.float32)
        for i in range(n):
            start = max(0, i - T + 1)
            window = X_sorted[start : i + 1]   # (<=T, K)
            actual_len = len(window)

            # Add jitter to historical steps (not the current step)
            if actual_len > 1:
                jitter = self.rng.normal(
                    0, self.jitter_sigma, size=(actual_len - 1, K)
                ).astype(np.float32)
                window[:-1] += jitter

            # Right-align in the T-length window (most recent = last)
            seqs[i, T - actual_len:, :] = window

        # Restore original module order
        seqs = seqs[reverse_order]
        return seqs   # (n, T, K)

    def build_single(self, x: np.ndarray) -> np.ndarray:
        """
        x : (K,) single module features
        Returns (1, T, K) with replicated + jittered steps
        """
        K = x.shape[0]
        seq = np.zeros((self.T, K), dtype=np.float32)
        for t in range(self.T):
            noise_scale = self.jitter_sigma * (self.T - t) / self.T
            seq[t] = x + self.rng.normal(0, noise_scale, size=K)
        seq[-1] = x   # current step has no jitter
        return seq[np.newaxis]   # (1, T, K)


def collate_sequences(seqs: np.ndarray, labels: np.ndarray,
                      batch_size: int = 64,
                      shuffle: bool = True,
                      seed: int = 42):
    """
    Simple numpy-based batch iterator. Returns (batch_seqs, batch_labels)
    as numpy arrays. Convert to torch tensors in the training loop.
    """
    n = len(seqs)
    rng = np.random.default_rng(seed)
    indices = np.arange(n)

    while True:
        if shuffle:
            rng.shuffle(indices)
        for start in range(0, n, batch_size):
            batch_idx = indices[start : start + batch_size]
            yield seqs[batch_idx], labels[batch_idx]
