"""
evaluation/metrics.py
----------------------
Full evaluation suite:
    - Per-fold metrics: F1, AUC-ROC, MCC, Precision, Recall, Accuracy
    - Mean ± SD and 95% CI across folds
    - Wilcoxon signed-rank test vs baselines (Bonferroni corrected)
    - Cohen's d effect sizes
    - Results table printer
"""

import numpy as np
from sklearn.metrics import (
    f1_score, roc_auc_score, matthews_corrcoef,
    precision_score, recall_score, accuracy_score
)
from scipy import stats
from typing import Dict, List, Tuple, Optional


# ─── PER-SAMPLE METRICS ──────────────────────────────────────────────────────

def compute_all_metrics(y_true: np.ndarray, y_prob: np.ndarray,
                        threshold: float = 0.5) -> Dict[str, float]:
    y_pred = (y_prob >= threshold).astype(int)
    try:
        auc = roc_auc_score(y_true, y_prob)
    except ValueError:
        auc = 0.5
    return {
        "accuracy":  accuracy_score(y_true, y_pred),
        "f1":        f1_score(y_true, y_pred, zero_division=0),
        "auc":       auc,
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall":    recall_score(y_true, y_pred, zero_division=0),
        "mcc":       matthews_corrcoef(y_true, y_pred),
    }


# ─── FOLD AGGREGATION ─────────────────────────────────────────────────────────

def aggregate_folds(fold_metrics: List[Dict[str, float]]) -> Dict[str, Dict]:
    """
    Given a list of per-fold metric dicts, return:
        mean, std, 95% CI, min, max per metric.
    CI via t-distribution (df = n_folds - 1).
    """
    keys = fold_metrics[0].keys()
    n = len(fold_metrics)
    result = {}
    t_crit = stats.t.ppf(0.975, df=n - 1)   # two-tailed 95%

    for key in keys:
        vals = np.array([m[key] for m in fold_metrics])
        mu   = vals.mean()
        sd   = vals.std(ddof=1)
        ci   = t_crit * sd / np.sqrt(n)
        result[key] = {
            "mean": mu, "std": sd, "ci95": ci,
            "min": vals.min(), "max": vals.max()
        }
    return result


# ─── STATISTICAL TESTS ───────────────────────────────────────────────────────

def wilcoxon_vs_baselines(our_fold_f1: np.ndarray,
                          baseline_fold_f1s: Dict[str, np.ndarray],
                          alpha: float = 0.05) -> Dict[str, Dict]:
    """
    Wilcoxon signed-rank test (paired, per-fold F1 scores).
    Bonferroni correction: alpha / n_comparisons.
    Returns dict with p-value, significant flag, Cohen's d for each baseline.
    """
    n_comparisons = len(baseline_fold_f1s)
    alpha_corrected = alpha / max(n_comparisons, 1)
    results = {}

    for name, baseline_f1s in baseline_fold_f1s.items():
        if len(our_fold_f1) != len(baseline_f1s):
            continue
        try:
            stat, p = stats.wilcoxon(our_fold_f1, baseline_f1s,
                                     alternative="greater")
        except ValueError:
            p = 1.0
        significant = p < alpha_corrected

        # Cohen's d
        diff = our_fold_f1 - baseline_f1s
        d = diff.mean() / (diff.std(ddof=1) + 1e-9)

        results[name] = {
            "p_value": p,
            "p_corrected_alpha": alpha_corrected,
            "significant": significant,
            "cohens_d": d,
            "our_mean": our_fold_f1.mean(),
            "baseline_mean": baseline_f1s.mean(),
            "delta": our_fold_f1.mean() - baseline_f1s.mean()
        }
    return results


# ─── RESULTS TABLE PRINTER ────────────────────────────────────────────────────

def print_results_table(dataset_name: str,
                        agg: Dict[str, Dict],
                        fold_metrics: Optional[List[Dict]] = None):
    """Print a clean per-metric summary table for one dataset."""
    print(f"\n{'='*60}")
    print(f"  Results for: {dataset_name}")
    print(f"{'='*60}")
    print(f"  {'Metric':<12} {'Mean':>8} {'±SD':>8} {'95% CI':>10} "
          f"{'Min':>8} {'Max':>8}")
    print(f"  {'-'*56}")
    for key in ["accuracy", "f1", "auc", "precision", "recall", "mcc"]:
        v = agg[key]
        print(f"  {key:<12} {v['mean']:>8.4f} {v['std']:>8.4f} "
              f"{'±'+f'{v[\"ci95\"]:.4f}':>10} {v['min']:>8.4f} {v['max']:>8.4f}")

    if fold_metrics:
        print(f"\n  Fold-wise F1:")
        fold_f1s = [m["f1"] for m in fold_metrics]
        print("  " + "  ".join(f"F{i+1}:{v:.3f}" for i, v in enumerate(fold_f1s)))


def print_comparison_table(method_results: Dict[str, Dict]):
    """Print a side-by-side comparison of multiple methods."""
    print(f"\n{'='*72}")
    print(f"  {'Method':<30} {'F1':>8} {'AUC':>8} {'MCC':>8} {'Acc':>8}")
    print(f"  {'-'*68}")
    for name, agg in method_results.items():
        f1  = agg["f1"]["mean"]
        auc = agg["auc"]["mean"]
        mcc = agg["mcc"]["mean"]
        acc = agg["accuracy"]["mean"]
        print(f"  {name:<30} {f1:>8.4f} {auc:>8.4f} {mcc:>8.4f} {acc:>8.4f}")
    print(f"{'='*72}")


def print_statistical_tests(wilcoxon_results: Dict[str, Dict]):
    print(f"\n  Wilcoxon signed-rank test (Bonferroni corrected):")
    print(f"  {'Baseline':<20} {'p-value':>10} {'Sig?':>6} "
          f"{'Cohen d':>9} {'Delta F1':>10}")
    print(f"  {'-'*58}")
    for name, r in wilcoxon_results.items():
        sig = "YES" if r["significant"] else "no"
        print(f"  {name:<20} {r['p_value']:>10.4f} {sig:>6} "
              f"{r['cohens_d']:>9.3f} {r['delta']:>10.4f}")
