"""
models/msh_bilstm.py
---------------------
Multi-Scale Hierarchical BiLSTM with Self-then-Cross Attention.

Architecture (Phase 3, corrected):
    Input X_T (T x K)
        |
        +---> Fine-grained BiLSTM  (step=1)   -> H_fine   (T   x 2H)
        |
        +---> Coarse-grained BiLSTM (step=K)  -> H_coarse (T/K x 2H)
        |
    STEP 1: self-attention on each stream independently
        H_fine*   = SelfAttn(H_fine)   + H_fine   (residual + LayerNorm)
        H_coarse* = SelfAttn(H_coarse) + H_coarse (residual + LayerNorm)
        |
    STEP 2: cross-attention (parallel, both directions)
        F_fine   = CrossAttn(Q=H_fine*,   KV=H_coarse*) + H_fine*
        F_coarse = CrossAttn(Q=H_coarse*, KV=H_fine*)   + H_coarse*
        |
    Pool + project -> v_final (2H,)
        |
    Dense head -> P(defect | x)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Optional


# ─── BUILDING BLOCKS ─────────────────────────────────────────────────────────

class AdditiveAttention(nn.Module):
    """
    Bahdanau-style additive attention.
    score(q, k) = v^T · tanh(W_q · q + W_k · k)

    Better sample-efficiency than dot-product at small T (< 20).
    Inputs:
        query : (B, T_q, d)
        key   : (B, T_k, d)
        value : (B, T_k, d)
    Output:
        context : (B, T_q, d)
        weights : (B, T_q, T_k)  — for interpretability
    """

    def __init__(self, d_model: int, dropout: float = 0.1):
        super().__init__()
        self.W_q    = nn.Linear(d_model, d_model, bias=False)
        self.W_k    = nn.Linear(d_model, d_model, bias=False)
        self.v      = nn.Linear(d_model, 1,        bias=False)
        self.dropout = nn.Dropout(dropout)
        self.scale  = d_model ** 0.5

    def forward(self, query: torch.Tensor,
                key:   torch.Tensor,
                value: torch.Tensor,
                key_padding_mask: Optional[torch.Tensor] = None):
        # query: (B, T_q, d), key: (B, T_k, d)
        B, T_q, d = query.shape
        T_k = key.shape[1]

        q_exp = self.W_q(query).unsqueeze(2).expand(-1, -1, T_k, -1)  # (B,T_q,T_k,d)
        k_exp = self.W_k(key).unsqueeze(1).expand(-1, T_q, -1, -1)    # (B,T_q,T_k,d)

        scores = self.v(torch.tanh(q_exp + k_exp)).squeeze(-1)         # (B,T_q,T_k)
        scores = scores / self.scale

        if key_padding_mask is not None:
            scores = scores.masked_fill(key_padding_mask.unsqueeze(1), float("-inf"))

        weights = F.softmax(scores, dim=-1)                            # (B,T_q,T_k)
        weights = self.dropout(weights)
        context = torch.bmm(weights, value)                            # (B,T_q,d)
        return context, weights


class SelfAttentionBlock(nn.Module):
    """Self-attention with residual connection and LayerNorm."""

    def __init__(self, d_model: int, dropout: float = 0.1):
        super().__init__()
        self.attn  = AdditiveAttention(d_model, dropout)
        self.norm  = nn.LayerNorm(d_model)
        self.drop  = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, T, d_model)
        ctx, _ = self.attn(x, x, x)
        return self.norm(x + self.drop(ctx))


class CrossAttentionBlock(nn.Module):
    """Cross-attention with residual connection and LayerNorm."""

    def __init__(self, d_model: int, dropout: float = 0.1):
        super().__init__()
        self.attn = AdditiveAttention(d_model, dropout)
        self.norm = nn.LayerNorm(d_model)
        self.drop = nn.Dropout(dropout)

    def forward(self, query_seq: torch.Tensor,
                kv_seq: torch.Tensor) -> tuple:
        # query_seq: (B, T_q, d), kv_seq: (B, T_kv, d)
        ctx, weights = self.attn(query_seq, kv_seq, kv_seq)
        out = self.norm(query_seq + self.drop(ctx))
        return out, weights


# ─── DUAL BILSTM ENCODER ─────────────────────────────────────────────────────

class DualBiLSTMEncoder(nn.Module):
    """
    Two separate BiLSTM modules at different temporal granularities.

    Fine stream  : processes every version step
    Coarse stream: processes mean-pooled windows of K steps

    Then:
        Step 1 — self-attention on each stream
        Step 2 — cross-attention both directions (parallel)
    """

    def __init__(self, input_dim: int, hidden_dim: int = 64,
                 coarse_k: int = 3, num_layers: int = 2,
                 dropout: float = 0.30, share_self_attn: bool = True):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.coarse_k   = coarse_k
        d = hidden_dim * 2   # bidirectional output dim

        # Two separate BiLSTM modules
        self.bilstm_fine = nn.LSTM(
            input_dim, hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_layers > 1 else 0.0
        )
        self.bilstm_coarse = nn.LSTM(
            input_dim, hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_layers > 1 else 0.0
        )

        # Step 1: self-attention
        # share_self_attn = True: one set of weights for both streams
        #   -> halves param count, helps on tiny datasets (CM1, MC2)
        # share_self_attn = False: separate weights
        #   -> more expressive for larger datasets (JM1, KC1)
        if share_self_attn:
            shared = SelfAttentionBlock(d, dropout)
            self.self_attn_fine   = shared
            self.self_attn_coarse = shared
        else:
            self.self_attn_fine   = SelfAttentionBlock(d, dropout)
            self.self_attn_coarse = SelfAttentionBlock(d, dropout)

        # Step 2: cross-attention (two directions)
        self.cross_attn_f2c = CrossAttentionBlock(d, dropout)  # fine  queries coarse
        self.cross_attn_c2f = CrossAttentionBlock(d, dropout)  # coarse queries fine

        # Project concatenated pooled vectors back to d
        self.proj = nn.Sequential(
            nn.Linear(d * 2, d),
            nn.LayerNorm(d),
            nn.ReLU()
        )

    def _pool_to_coarse(self, x: torch.Tensor) -> torch.Tensor:
        """Mean-pool x (B, T, K) into windows of size coarse_k."""
        B, T, K_feat = x.shape
        # Pad T to be divisible by coarse_k
        pad = (self.coarse_k - T % self.coarse_k) % self.coarse_k
        if pad > 0:
            x = F.pad(x, (0, 0, 0, pad))
        T_pad = x.shape[1]
        # Reshape and mean-pool: (B, T_pad/K, K, feat) -> (B, T_pad/K, feat)
        x = x.reshape(B, T_pad // self.coarse_k, self.coarse_k, K_feat)
        return x.mean(dim=2)

    def forward(self, x: torch.Tensor):
        """
        x: (B, T, input_dim) — padded version sequence for a batch of modules
        Returns v_final: (B, 2H) for each module
        Also returns attention weights for interpretability.
        """
        B, T, _ = x.shape

        # ── BiLSTM encoding ───────────────────────────────────────────────────
        H_fine,   _ = self.bilstm_fine(x)                       # (B, T,   2H)
        x_coarse    = self._pool_to_coarse(x)                   # (B, T/K, input_dim)
        H_coarse, _ = self.bilstm_coarse(x_coarse)              # (B, T/K, 2H)

        # ── Step 1: self-attention ─────────────────────────────────────────────
        H_fine_star   = self.self_attn_fine(H_fine)             # (B, T,   2H)
        H_coarse_star = self.self_attn_coarse(H_coarse)         # (B, T/K, 2H)

        # ── Step 2: cross-attention (parallel) ────────────────────────────────
        # Fine queries coarse — fine learns what long-range drift signals matter
        F_fine,   w_f2c = self.cross_attn_f2c(H_fine_star,   H_coarse_star)
        # Coarse queries fine — coarse learns which version steps anchor it
        F_coarse, w_c2f = self.cross_attn_c2f(H_coarse_star, H_fine_star)

        # ── Pool and project ───────────────────────────────────────────────────
        v_fine   = F_fine.mean(dim=1)                           # (B, 2H)
        v_coarse = F_coarse.mean(dim=1)                         # (B, 2H)
        v_final  = self.proj(torch.cat([v_fine, v_coarse], dim=-1))  # (B, 2H)

        return v_final, {"w_f2c": w_f2c, "w_c2f": w_c2f}


# ─── FULL CLASSIFIER ─────────────────────────────────────────────────────────

class MSHBiLSTM(nn.Module):
    """
    Full MSH-BiLSTM classifier.

    Phases covered by this module:
        Phase 3: DualBiLSTMEncoder (self + cross attention)
        Phase 4: single dense classification head
    """

    def __init__(self, input_dim: int, hidden_dim: int = 64,
                 coarse_k: int = 3, num_layers: int = 2,
                 dropout: float = 0.30, share_self_attn: bool = True):
        super().__init__()
        self.encoder = DualBiLSTMEncoder(
            input_dim=input_dim,
            hidden_dim=hidden_dim,
            coarse_k=coarse_k,
            num_layers=num_layers,
            dropout=dropout,
            share_self_attn=share_self_attn
        )
        d = hidden_dim * 2
        self.head = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(d, 1)
        )

    def forward(self, x: torch.Tensor):
        v_final, attn_weights = self.encoder(x)
        logit = self.head(v_final).squeeze(-1)          # (B,)
        return logit, attn_weights

    def predict_proba(self, x: torch.Tensor) -> torch.Tensor:
        logit, _ = self.forward(x)
        return torch.sigmoid(logit)

    def count_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)
