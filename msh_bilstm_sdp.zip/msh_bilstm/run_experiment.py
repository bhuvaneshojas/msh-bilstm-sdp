"""
run_experiment.py
-----------------
Full 10-fold nested cross-validation pipeline for MSH-BiLSTM.

Usage (after installing requirements):
    python run_experiment.py --dataset KC1 --data_path data/raw/kc1.arff
    python run_experiment.py --dataset KC1 --synthetic   # smoke test with fake data

Requirements:
    pip install torch scikit-learn imbalanced-learn scipy

Produces:
    - Per-fold metrics printed to stdout
    - Mean ± SD / 95% CI table
    - Wilcoxon test vs SMOTE+RF baseline
    - Attention weight arrays saved to results/{dataset}/fold_{k}_attn.npy
    - Full fold metrics saved to results/{dataset}/fold_metrics.npy
"""

import os
import argparse
import numpy as np
import warnings
warnings.filterwarnings("ignore")

from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score

# ── Local imports ──────────────────────────────────────────────────────────────
import sys
sys.path.insert(0, os.path.dirname(__file__))

from data.loader       import load_promise_dataset, make_synthetic_promise
from data.preprocessing import Preprocessor, AFSSHAPSelector, augment_with_dcgan
from data.sequencer    import SequenceBuilder
from evaluation.metrics import (
    compute_all_metrics, aggregate_folds,
    wilcoxon_vs_baselines,
    print_results_table, print_comparison_table, print_statistical_tests
)


# ─────────────────────────────────────────────────────────────────────────────
def try_import_torch():
    try:
        import torch
        return torch
    except ImportError:
        return None


def run_single_fold(X_train: np.ndarray, y_train: np.ndarray,
                    X_test: np.ndarray,  y_test: np.ndarray,
                    feature_names: list, args, fold_idx: int,
                    torch_module) -> dict:
    """
    Full pipeline for one fold:
        1. Preprocess
        2. AFS-SHAP feature selection
        3. DC-GAN augmentation (or SMOTE fallback)
        4. Build sequences
        5. Train MSH-BiLSTM
        6. Evaluate
    Returns per-fold metrics dict.
    """
    print(f"\n  --- Fold {fold_idx+1} ---")

    # Phase 1: Preprocess
    prep = Preprocessor(iqr_k=1.5)
    X_tr_n = prep.fit_transform(X_train)
    X_te_n = prep.transform(X_test)

    # Phase 2a: Feature selection
    selector = AFSSHAPSelector(
        alpha=args.afs_alpha,
        k_max=args.k_features,
        n_trees=100,
        random_state=args.seed
    )
    X_tr_sel = selector.fit_transform(X_tr_n, y_train, feature_names)
    X_te_sel = selector.transform(X_te_n)
    K = X_tr_sel.shape[1]

    # Phase 2b: GAN augmentation (inner-train only to prevent leakage)
    # Further split inner train into inner-train / inner-val for early stopping
    inner_skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=args.seed)
    inner_splits = list(inner_skf.split(X_tr_sel, y_train))
    inner_tr_idx, inner_val_idx = inner_splits[0]  # use first inner fold

    X_inner_tr  = X_tr_sel[inner_tr_idx]
    y_inner_tr  = y_train[inner_tr_idx]
    X_inner_val = X_tr_sel[inner_val_idx]
    y_inner_val = y_train[inner_val_idx]

    # Augment only inner training portion
    if args.use_gan and torch_module is not None:
        X_aug, y_aug = augment_with_dcgan(
            X_inner_tr, y_inner_tr,
            latent_dim=100,
            epochs=args.gan_epochs,
            device=args.device,
            seed=args.seed
        )
    else:
        from imblearn.over_sampling import SMOTE
        X_aug, y_aug = SMOTE(random_state=args.seed).fit_resample(
            X_inner_tr, y_inner_tr
        )
        print(f"  SMOTE augmented: {len(X_inner_tr)} -> {len(X_aug)}")

    # Phase 3+4: Build sequences and train MSH-BiLSTM
    seq_builder = SequenceBuilder(
        T=args.seq_len,
        sort_col=-1,
        jitter_sigma=0.05,
        seed=args.seed
    )
    S_aug      = seq_builder.build(X_aug)
    S_val      = seq_builder.build(X_inner_val)
    S_test     = seq_builder.build(X_te_sel)

    if torch_module is None:
        print("  torch not available — using RF baseline instead of MSH-BiLSTM")
        rf = RandomForestClassifier(n_estimators=200, random_state=args.seed)
        rf.fit(X_aug, y_aug)
        probs = rf.predict_proba(X_te_sel)[:, 1]
        metrics = compute_all_metrics(y_test, probs, threshold=0.5)
        metrics["model"] = "RF_fallback"
        return metrics

    # Import model and trainer here (requires torch)
    from models.msh_bilstm import MSHBiLSTM
    from training.trainer  import Trainer

    model = MSHBiLSTM(
        input_dim=K,
        hidden_dim=args.hidden_dim,
        coarse_k=args.coarse_k,
        num_layers=args.num_layers,
        dropout=args.dropout,
        share_self_attn=args.share_self_attn
    )
    print(f"  Model parameters: {model.count_parameters():,}")

    trainer = Trainer(
        model=model,
        lr=args.lr,
        max_epochs=args.max_epochs,
        patience=args.patience,
        batch_size=args.batch_size,
        device=args.device,
        seed=args.seed
    )
    trainer.fit(S_aug, y_aug, S_val, y_inner_val, verbose=args.verbose)

    # Evaluate on held-out test fold
    probs    = trainer.predict_proba(S_test)
    metrics  = compute_all_metrics(y_test, probs, threshold=trainer.best_threshold)
    metrics["threshold"] = trainer.best_threshold
    metrics["model"] = "MSH-BiLSTM"

    print(f"  Fold {fold_idx+1} results: "
          f"F1={metrics['f1']:.4f} AUC={metrics['auc']:.4f} "
          f"MCC={metrics['mcc']:.4f}")

    return metrics


# ─────────────────────────────────────────────────────────────────────────────
def run_rf_baseline(X: np.ndarray, y: np.ndarray, n_folds: int = 10,
                    seed: int = 42) -> list:
    """Run RF+SMOTE baseline for Wilcoxon comparison."""
    from imblearn.over_sampling import SMOTE
    skf    = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=seed)
    fold_metrics = []
    for tr_idx, te_idx in skf.split(X, y):
        X_tr, X_te = X[tr_idx], X[te_idx]
        y_tr, y_te = y[tr_idx], y[te_idx]
        X_aug, y_aug = SMOTE(random_state=seed).fit_resample(X_tr, y_tr)
        rf = RandomForestClassifier(n_estimators=200, random_state=seed)
        rf.fit(X_aug, y_aug)
        probs = rf.predict_proba(X_te)[:, 1]
        fold_metrics.append(compute_all_metrics(y_te, probs))
    return fold_metrics


# ─────────────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="MSH-BiLSTM SDP Experiment")

    # Dataset
    parser.add_argument("--dataset",   default="KC1")
    parser.add_argument("--data_path", default="data/raw/kc1.arff")
    parser.add_argument("--synthetic", action="store_true",
                        help="Use synthetic data (smoke test without real .arff)")

    # Architecture
    parser.add_argument("--hidden_dim",     type=int,   default=64)
    parser.add_argument("--coarse_k",       type=int,   default=3)
    parser.add_argument("--num_layers",     type=int,   default=2)
    parser.add_argument("--dropout",        type=float, default=0.30)
    parser.add_argument("--share_self_attn",action="store_true", default=True)
    parser.add_argument("--seq_len",        type=int,   default=5)

    # Feature selection
    parser.add_argument("--afs_alpha",   type=float, default=0.6)
    parser.add_argument("--k_features",  type=int,   default=None,
                        help="Fix K; None=auto greedy selection")

    # GAN
    parser.add_argument("--use_gan",    action="store_true", default=True)
    parser.add_argument("--gan_epochs", type=int,   default=300)

    # Training
    parser.add_argument("--lr",          type=float, default=3e-4)
    parser.add_argument("--max_epochs",  type=int,   default=200)
    parser.add_argument("--patience",    type=int,   default=15)
    parser.add_argument("--batch_size",  type=int,   default=64)
    parser.add_argument("--n_folds",     type=int,   default=10)
    parser.add_argument("--device",      default="cpu")  # "cuda" if GPU available
    parser.add_argument("--seed",        type=int,   default=42)
    parser.add_argument("--verbose",     action="store_true", default=True)

    args = parser.parse_args()

    torch_module = try_import_torch()
    if torch_module is None:
        print("WARNING: torch not installed. Model will fall back to RF baseline.")
        print("Install with: pip install torch")

    # ── Load data ──────────────────────────────────────────────────────────────
    if args.synthetic:
        print("Using synthetic data (smoke test mode)")
        X, y, feature_names = make_synthetic_promise(n=500, d=21, seed=args.seed)
    else:
        X, y, feature_names = load_promise_dataset(args.data_path)

    print(f"\nDataset: {args.dataset} | n={len(X)} | "
          f"defect rate={100*y.mean():.1f}%")

    # ── 10-fold stratified CV ─────────────────────────────────────────────────
    skf = StratifiedKFold(
        n_splits=args.n_folds, shuffle=True, random_state=args.seed
    )
    fold_metrics = []

    for fold_idx, (tr_idx, te_idx) in enumerate(skf.split(X, y)):
        metrics = run_single_fold(
            X[tr_idx], y[tr_idx],
            X[te_idx],  y[te_idx],
            feature_names, args, fold_idx, torch_module
        )
        fold_metrics.append(metrics)

    # ── Aggregate and print ───────────────────────────────────────────────────
    agg = aggregate_folds(fold_metrics)
    print_results_table(args.dataset, agg, fold_metrics)

    # ── RF baseline for Wilcoxon ──────────────────────────────────────────────
    print(f"\nRunning RF+SMOTE baseline for statistical comparison...")
    rf_fold_metrics = run_rf_baseline(X, y, n_folds=args.n_folds, seed=args.seed)
    rf_agg = aggregate_folds(rf_fold_metrics)

    our_f1s = np.array([m["f1"] for m in fold_metrics])
    rf_f1s  = np.array([m["f1"] for m in rf_fold_metrics])
    wx_results = wilcoxon_vs_baselines(our_f1s, {"RF+SMOTE": rf_f1s})
    print_statistical_tests(wx_results)

    print_comparison_table({
        "MSH-BiLSTM (ours)": agg,
        "RF+SMOTE (baseline)": rf_agg
    })

    # ── Save results ──────────────────────────────────────────────────────────
    out_dir = f"results/{args.dataset}"
    os.makedirs(out_dir, exist_ok=True)
    np.save(f"{out_dir}/fold_metrics.npy", fold_metrics)
    print(f"\nResults saved to {out_dir}/fold_metrics.npy")
    print("\nDone.")


if __name__ == "__main__":
    main()
