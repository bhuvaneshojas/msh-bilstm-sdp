"""
training/trainer.py
--------------------
Training loop for MSH-BiLSTM.

Features:
    - Class-weighted binary cross-entropy (handles residual imbalance
      after GAN augmentation)
    - Cosine annealing LR schedule
    - Early stopping on validation F1 (patience = 15)
    - Youden's J threshold search on validation fold
    - Gradient clipping (max_norm = 1.0)
"""

import numpy as np
import torch
import torch.nn as nn
from torch.optim.lr_scheduler import CosineAnnealingLR
from sklearn.metrics import f1_score, roc_auc_score, matthews_corrcoef
from typing import Tuple, Dict, Optional
import time


def compute_class_weight(y: np.ndarray) -> float:
    """pos_weight for BCEWithLogitsLoss: n_neg / n_pos."""
    n_pos = y.sum()
    n_neg = len(y) - n_pos
    return float(n_neg / max(n_pos, 1))


def find_best_threshold(probs: np.ndarray, labels: np.ndarray,
                        thresholds: Optional[np.ndarray] = None) -> float:
    """Youden's J = Sensitivity + Specificity - 1. Maximise over thresholds."""
    if thresholds is None:
        thresholds = np.linspace(0.1, 0.9, 81)
    best_j, best_t = -1.0, 0.5
    for t in thresholds:
        preds = (probs >= t).astype(int)
        if preds.sum() == 0 or preds.sum() == len(preds):
            continue
        tp = ((preds == 1) & (labels == 1)).sum()
        tn = ((preds == 0) & (labels == 0)).sum()
        fp = ((preds == 1) & (labels == 0)).sum()
        fn = ((preds == 0) & (labels == 1)).sum()
        sens = tp / max(tp + fn, 1)
        spec = tn / max(tn + fp, 1)
        j = sens + spec - 1
        if j > best_j:
            best_j, best_t = j, t
    return best_t


class Trainer:
    def __init__(self, model: nn.Module,
                 lr: float = 3e-4,
                 max_epochs: int = 200,
                 patience: int = 15,
                 batch_size: int = 64,
                 device: str = "cpu",
                 seed: int = 42):
        self.model      = model.to(device)
        self.device     = device
        self.max_epochs = max_epochs
        self.patience   = patience
        self.batch_size = batch_size
        self.seed       = seed
        self.lr         = lr

        self.optimizer = torch.optim.Adam(
            model.parameters(), lr=lr, betas=(0.9, 0.999)
        )
        self.scheduler = CosineAnnealingLR(
            self.optimizer, T_max=max_epochs, eta_min=1e-6
        )
        self.history: Dict[str, list] = {
            "train_loss": [], "val_f1": [], "val_auc": []
        }
        self.best_threshold = 0.5

    def _to_tensor(self, x: np.ndarray, dtype=torch.float32) -> torch.Tensor:
        return torch.tensor(x, dtype=dtype).to(self.device)

    def _get_batches(self, X: np.ndarray, y: np.ndarray, shuffle: bool = True):
        n = len(X)
        rng = np.random.default_rng(self.seed)
        idx = np.arange(n)
        if shuffle:
            rng.shuffle(idx)
        for start in range(0, n, self.batch_size):
            b = idx[start: start + self.batch_size]
            yield X[b], y[b]

    def fit(self, X_train: np.ndarray, y_train: np.ndarray,
            X_val: np.ndarray,   y_val: np.ndarray,
            verbose: bool = True) -> "Trainer":

        pos_weight = torch.tensor(
            [compute_class_weight(y_train)], dtype=torch.float32
        ).to(self.device)
        criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)

        best_val_f1   = -1.0
        best_state    = None
        no_improve    = 0
        best_epoch    = 0

        for epoch in range(1, self.max_epochs + 1):
            # ── TRAIN ─────────────────────────────────────────────────────────
            self.model.train()
            epoch_loss = 0.0
            n_batches  = 0
            for Xb, yb in self._get_batches(X_train, y_train):
                Xb_t = self._to_tensor(Xb)
                yb_t = self._to_tensor(yb, torch.float32)

                self.optimizer.zero_grad()
                logit, _ = self.model(Xb_t)
                loss = criterion(logit, yb_t)
                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                self.optimizer.step()

                epoch_loss += loss.item()
                n_batches  += 1

            self.scheduler.step()
            avg_loss = epoch_loss / max(n_batches, 1)
            self.history["train_loss"].append(avg_loss)

            # ── VALIDATE ──────────────────────────────────────────────────────
            val_f1, val_auc, val_probs = self._evaluate(X_val, y_val)
            self.history["val_f1"].append(val_f1)
            self.history["val_auc"].append(val_auc)

            if val_f1 > best_val_f1:
                best_val_f1 = val_f1
                best_state  = {k: v.cpu().clone()
                               for k, v in self.model.state_dict().items()}
                best_epoch  = epoch
                no_improve  = 0
                # Update Youden's J threshold on validation fold
                self.best_threshold = find_best_threshold(
                    val_probs, y_val
                )
            else:
                no_improve += 1

            if verbose and epoch % 10 == 0:
                print(f"  epoch {epoch:03d} | loss {avg_loss:.4f} | "
                      f"val_f1 {val_f1:.4f} | val_auc {val_auc:.4f} | "
                      f"theta {self.best_threshold:.2f}")

            if no_improve >= self.patience:
                if verbose:
                    print(f"  Early stop at epoch {epoch} "
                          f"(best epoch {best_epoch}, val_f1 {best_val_f1:.4f})")
                break

        # Restore best weights
        if best_state is not None:
            self.model.load_state_dict(best_state)

        return self

    @torch.no_grad()
    def _evaluate(self, X: np.ndarray, y: np.ndarray
                  ) -> Tuple[float, float, np.ndarray]:
        self.model.eval()
        all_probs = []
        for Xb, _ in self._get_batches(X, y, shuffle=False):
            Xb_t  = self._to_tensor(Xb)
            logit, _ = self.model(Xb_t)
            probs = torch.sigmoid(logit).cpu().numpy()
            all_probs.append(probs)

        probs  = np.concatenate(all_probs)
        preds  = (probs >= self.best_threshold).astype(int)

        f1  = f1_score(y, preds, zero_division=0)
        try:
            auc = roc_auc_score(y, probs)
        except ValueError:
            auc = 0.5
        return f1, auc, probs

    @torch.no_grad()
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        self.model.eval()
        all_probs = []
        for Xb, _ in self._get_batches(X, np.zeros(len(X)), shuffle=False):
            Xb_t  = self._to_tensor(Xb)
            logit, _ = self.model(Xb_t)
            all_probs.append(torch.sigmoid(logit).cpu().numpy())
        return np.concatenate(all_probs)

    @torch.no_grad()
    def get_attention_weights(self, X: np.ndarray) -> Dict[str, np.ndarray]:
        """Return cross-attention weights for interpretability analysis."""
        self.model.eval()
        Xt = self._to_tensor(X)
        _, attn = self.model(Xt)
        return {k: v.cpu().numpy() for k, v in attn.items()}
